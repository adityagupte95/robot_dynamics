clc
clear all 


d=[330;0;0;320;0;80];
a=[75;300;75;0;0;0];
al=[90;0;90;-90;90;0];
for x=1:6
    prompt = sprintf('Enter Value of theta%d=',x);
    t(x,1)=input(prompt); %#ok<SAGROW>
end

t(1,1)=t(1,1)+90;
t(2,1)=t(2,1)+90;


A=zeros(4,4,6);
for x= 1:6


     A(:,:,x)=[cosd(t(x,1)) -sind(t(x,1))*cosd(al(x,1)) sind(t(x,1))*sind(al(x,1)) a(x,1)*cosd(t(x,1)); ...
              sind(t(x,1)) cosd(t(x,1))*cosd(al(x,1)) -cosd(t(x,1))*sind(al(x,1)) a(x,1)*sind(t(x,1)); ...
              0 sind(al(x,1)) cosd(al(x,1)) d(x,1); ...
              0 0 0 1  ];
          
end  
A
    
T=eye(4,4);
for y=1:6
    T=T*A(:,:,y);
end
% print('Matrix T6 is')
T

X=zeros(4,4,6);
X(:,:,1)=A(:,:,1);
for i=2:6
X(:,:,i)=X(:,:,i-1)*A(:,:,i);
end
p(1,:)=[0 0 0];
for j=2:7
        for i=1:3
    P(j,i)=X(i,4,j-1);
        end
end
% xlabel('x-axis')
% ylabel('y-axis')
% zlabel('z-axis')
% text(0,0,0,[' Joint 1 = ',num2str(t(1,1))])
% text(p(1,1),p(1,2),p(1,3),[' Joint 2 = ',num2str(t(2,1))])
% text(p(2,1),p(2,2),p(2,3),[' Joint 3 = ',num2str(t(3))])
% text(p(3,1),p(3,2),p(3,3),[' Joint 4 = ',num2str(t(4))])
% text(p(4,1),p(4,2),p(4,3),[' Joint 5,6 = ',num2str(t(4)),', ',num2str(th(5))])
% text(p6(1),p6(2),p6(3),'End Effector')
    
pts=[P(1,:);P(2,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
pts=[P(2,:);P(3,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
pts=[P(3,:);P(4,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
pts=[P(4,:);P(5,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
pts=[P(5,:);P(6,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
pts=[P(6,:);P(7,:)]
plot3(pts(:,1),pts(:,2),pts(:,3),'-o','linewidth',2.5)
hold on
